package com.example.ladm_u2_p3_david_alejandro_hernandez_rubio

import android.annotation.SuppressLint
import android.annotation.TargetApi
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.MotionEvent
import android.view.View
import androidx.annotation.RequiresApi

class Lienzo (p: MainActivity): View (p) {
    var puntero = p
    var punteroDibujos : Dibujos ?= null




    var fondo = Dibujos(0,0,1500,2600)

    var esfera = Dibujos(150,600, BitmapFactory.decodeResource(resources,R.drawable.mesa))
    var iconoP1 = Dibujos(0,0,BitmapFactory.decodeResource(resources,R.drawable.usuario))
    var iconoP2 = Dibujos(1100,0,BitmapFactory.decodeResource(resources,R.drawable.usuario2))
    var iconoP3 = Dibujos(0,1370,BitmapFactory.decodeResource(resources,R.drawable.usuario3))
    var iconoP4 = Dibujos(1100,1360,BitmapFactory.decodeResource(resources,R.drawable.usuario4))


    var txtP1 = Dibujos("Jugador 1",20,400)
    var txtP2 = Dibujos("Jugador 2",1000,400)
    var txtP3 = Dibujos("Jugador 3",20,1850)
    var txtP4 = Dibujos("Jugador 4",1000,1850)


    var pountosP1 = Dibujos("Puntos : 0",20,480)
    var pountosP2 = Dibujos("Puntos : 0",1000,480)
    var pountosP3 = Dibujos("Puntos : 0",20,1990)
    var pountosP4 = Dibujos("Puntos : 0",1000,1990)

    var txt2P1 = Dibujos("Pausa",20,550)
    var txt2P2 = Dibujos("Pausa",1000,550)
    var txt2P3 = Dibujos("Pausa",20,1920)
    var txt2P4 = Dibujos("Pausa",1000,1920)


    var play = Dibujos(550,300,BitmapFactory.decodeResource(resources,R.drawable.iniciar))

    var dado1I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dado))
    var dado1D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dado))
    var dado2I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dados2))
    var dado2D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dados2))
    var dado3I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dados3))
    var dado3D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dados3))
    var dado4I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dados4))
    var dado4D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dados4))
    var dado5I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dados5))
    var dado5D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dados5))
    var dado6I = Dibujos(500,1020,BitmapFactory.decodeResource(resources,R.drawable.dados6))
    var dado6D = Dibujos(700,1020,BitmapFactory.decodeResource(resources,R.drawable.dados6))

    var D1I= false
    var D1D = false
    var D2I = false
    var D2D = false
    var D3I = false
    var D3D = false
    var D4I = false
    var D4D = false
    var D5I = false
    var D5D = false
    var D6I = false
    var D6D = false
    var start = false
    var tiro = false

    var puntoP1 = 0
    var puntoP2 = 0
    var puntoP3 = 0
    var puntoP4 = 0

    var puntosDI = 0
    var puntosDD = 0
    var lanzaJugador = 1
    var ronda = 1
    var contador = 0


    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var paint = Paint()



        paint.color = Color.rgb( 123, 175, 90)
        fondo.pintar(canvas,paint)
        esfera.pintar(canvas,paint)
        iconoP1.pintar(canvas,paint)
        iconoP2.pintar(canvas,paint)
        iconoP3.pintar(canvas,paint)
        iconoP4.pintar(canvas,paint)

        paint.color = Color.BLUE
        paint.textSize = 80f
        txtP1.pintar(canvas,paint)
        txtP2.pintar(canvas,paint)
        txtP3.pintar(canvas,paint)
        txtP4.pintar(canvas,paint)

        txt2P1.pintar(canvas,paint)
        txt2P2.pintar(canvas,paint)
        txt2P3.pintar(canvas,paint)
        txt2P4.pintar(canvas,paint)

        pountosP1.pintar(canvas,paint)
        pountosP2.pintar(canvas,paint)
        pountosP3.pintar(canvas,paint)
        pountosP4.pintar(canvas,paint)




        if (!start) {
            play.pintar(canvas, paint)
        }
        if (D1I)
            dado1I.pintar(canvas,paint)
        if (D1D)
            dado1D.pintar(canvas,paint)
        if (D2I)
            dado2I.pintar(canvas,paint)
        if (D2D)
            dado2D.pintar(canvas,paint)
        if (D3I)
            dado3I.pintar(canvas,paint)
        if (D3D)
            dado3D.pintar(canvas,paint)
        if (D4I)
            dado4I.pintar(canvas,paint)
        if (D4D)
            dado4D.pintar(canvas,paint)
        if (D5I)
            dado5I.pintar(canvas,paint)
        if (D5D)
            dado5D.pintar(canvas,paint)
        if (D6I)
            dado6I.pintar(canvas,paint)
        if (D6D)
            dado6D.pintar(canvas,paint)



        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {

                if (play.estaEnArea(event)) {
                    start = true
                    txt2P1.texto = "Jugando"
                    puntero.hiloP1!!.despausar()



                }


            }

        }
        invalidate()
        return true
    }

    fun tirarDados() {


        todosFalso()
        if (start) {

            if (ronda<5) {
                when ((1..6).random()) {

                    1 -> {
                        D1I = true
                        puntosDI = 1

                    }
                    2 -> {
                        D2I = true
                        puntosDI = 2
                    }
                    3 -> {
                        D3I = true
                        puntosDI = 3
                    }
                    4 -> {
                        D4I = true
                        puntosDI = 4
                    }
                    5 -> {
                        D5I = true
                        puntosDI = 5
                    }
                    6 -> {
                        D6I = true
                        puntosDI = 6
                    }
                }

                when ((1..6).random()) {
                    1 -> {
                        D1D = true
                        puntosDD = 1
                        correr()
                    }
                    2 -> {
                        D2D = true
                        puntosDD = 2

                    }
                    3 -> {
                        D3D = true
                        puntosDD = 3

                    }
                    4 -> {
                        D4D = true
                        puntosDD = 4

                    }
                    5 -> {
                        D5D = true
                        puntosDD = 5

                    }
                    6 -> {
                        D6D = true
                        puntosDD = 6

                    }
                }
                correr()
                despausarJugador(lanzaJugador)

            }else{
               txt2P1.texto = "Pausa"

                if (puntoP1>puntoP2 && puntoP1>puntoP3 && puntoP1>puntoP4)
                    mensaje("Ganador Jugado 1")
                if (puntoP2>puntoP1 && puntoP2>puntoP3 && puntoP2>puntoP4)
                    mensaje("Ganador Jugado 2")
                if (puntoP3>puntoP1 && puntoP3>puntoP2 && puntoP3>puntoP4)
                    mensaje("Ganador Jugado 2")
                if (puntoP4>puntoP1 && puntoP4>puntoP2 && puntoP4>puntoP3)
                    mensaje("Ganador Jugado 1")

                if (puntoP1 == puntoP2)
                    mensaje("EMPATE Jugador 1 y 2")
                if (puntoP1 == puntoP3)
                    mensaje("EMPATE Jugador 1 y 3")
                if (puntoP1 == puntoP4)
                    mensaje("EMPATE Jugador 1 y 4")

                if (puntoP2 == puntoP3)
                    mensaje("EMPATE Jugador 2 y 3")
                if (puntoP2 == puntoP4)
                    mensaje("EMPATE Jugador 2 y 4")

                if (puntoP3 == puntoP4)
                    mensaje("EMPATE Jugador 3 y 4")

                if (puntoP1==puntoP2 && puntoP1==puntoP3)
                    mensaje("EMPATE Jugador 1, 2 y 3")
                if (puntoP1==puntoP2 && puntoP1==puntoP4)
                    mensaje("EMPATE Jugador 1, 2 y 4")
                if (puntoP1==puntoP3 && puntoP1==puntoP4)
                    mensaje("EMPATE Jugador 1, 3 y 4")
                if (puntoP2==puntoP3 && puntoP1==puntoP3)
                    mensaje("EMPATE Jugador 2, 3 y 4")
                if (puntoP4==puntoP2 && puntoP4==puntoP3 && puntoP1 == puntoP4)
                    mensaje("EMPATE Jugador 1, 2, 3 y 4")

            }

        }
    }

    fun mensaje(mensaje:String){
        AlertDialog.Builder(puntero).setMessage(mensaje).show()
    }
    fun despausarJugador(jugado:Int){

        when(jugado){
            1->{
                puntero.hiloP1!!.despausar()
            }
            2->{
                puntero.hiloP2!!.despausar()

            }
            3->{
                puntero.hiloP3!!.despausar()
            }
            4->{
                puntero.hiloP4!!.despausar()
            }

        }
    }

    fun todosFalso(){
        D1I= false
        D1D = false
        D2I = false
        D2D = false
        D3I = false
        D3D = false
        D4I = false
        D4D = false
        D5I = false
        D5D = false
        D6I = false
        D6D = false
    }


    fun correr() {

        when(lanzaJugador){

            1->{


                puntoP1 += puntosDD + puntosDI
                puntero.hiloP1!!.pausar()
                pountosP1.texto = "Puntos : " + puntoP1
                lanzaJugador = 2
                puntero.setTitle("Ronda "+ ronda +" Lanzar Jugador "+ lanzaJugador)
                txt2P1.texto = "Pausa"
                txt2P2.texto = "Jugando"


            }
            2-> {
                puntoP2 += puntosDD + puntosDI
                puntero.hiloP2!!.pausar()
                pountosP2.texto = "Puntos : " + puntoP2
                lanzaJugador=3
                puntero.setTitle("Ronda "+ ronda +" Lanzar Jugador "+ lanzaJugador)
                txt2P2.texto = "Pausa"
                txt2P3.texto = "Jugando"



            }
            3->{
                puntoP3 += puntosDD + puntosDI

                pountosP3.texto = "Puntos : " + puntoP3
                lanzaJugador = 4
                puntero.setTitle("Ronda "+ ronda +" Lanzar Jugador "+ lanzaJugador)
                puntero.hiloP3!!.pausar()
                txt2P3.texto = "Pausa"
                txt2P4.texto = "Jugando"




            }
            4->{
                puntoP4 += puntosDD + puntosDI
                puntero.hiloP4!!.pausar()
                pountosP4.texto = "Puntos : " + puntoP4
                lanzaJugador = 1
                ronda++
                puntero.setTitle("Ronda "+ ronda +" Lanzar Jugador "+ lanzaJugador)
                txt2P4.texto = "Pausa"
                txt2P1.texto = "Jugando"




            }
        }

    }



}