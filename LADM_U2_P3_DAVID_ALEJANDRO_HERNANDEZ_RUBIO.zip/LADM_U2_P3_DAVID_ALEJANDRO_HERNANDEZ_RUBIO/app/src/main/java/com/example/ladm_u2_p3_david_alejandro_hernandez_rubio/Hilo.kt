package com.example.ladm_u2_p3_david_alejandro_hernandez_rubio

class Hilo(p:MainActivity) :Thread() {
    var puntero = p
    var pausa = false
    var iniciar = false

    fun pausar(){
        pausa = false
    }


    fun despausar(){
        pausa = true
    }

    override fun run() {
        super.run()
        iniciar = true
        while (iniciar) {
            sleep(1800)
            if (pausa) {
                puntero.runOnUiThread {
                    puntero.lienzo!!.tirarDados()
                }
            }
        }
    }

}