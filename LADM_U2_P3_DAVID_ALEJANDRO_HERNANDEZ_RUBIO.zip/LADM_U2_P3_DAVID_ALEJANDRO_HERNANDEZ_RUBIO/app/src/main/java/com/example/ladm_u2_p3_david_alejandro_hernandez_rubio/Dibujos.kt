package com.example.ladm_u2_p3_david_alejandro_hernandez_rubio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent

class Dibujos () {

    var x = 0f
    var y = 0f
    var radio = 0f
    var ancho = 0f
    var alto = 0f
    var tipo = 1
    var imagen : Bitmap?= null
    var texto = ""

    constructor(x:Int,y:Int,bitmap: Bitmap): this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        imagen = bitmap
        tipo = 3
        ancho = imagen!!.width.toFloat()
        alto = imagen!!.height.toFloat()
    }

    constructor(x:Int,y:Int,radio:Int): this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.radio = radio.toFloat()
        tipo = 1
        ancho = radio.toFloat()*2
        alto = ancho
    }

    constructor(x:Int,y:Int,ancho:Int,alto:Int): this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.radio = radio.toFloat()
        tipo = 2
        this.ancho = ancho.toFloat()
        this.alto = alto.toFloat()
    }
    constructor(texto:String,x:Int,y:Int): this(){
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.texto = texto
        Color.BLUE
        tipo = 4
    }


    fun pintar(c: Canvas, p: Paint){
        when(tipo){
            1->{
                c.drawCircle(x+radio,y+radio,radio,p)
            }
            2->{
                c.drawRect(x,y,x+ancho,y+alto,p)
            }
            3->{
                c.drawBitmap(imagen!!,x,y,p)
            }
            4->{
                c.drawText(texto,x,y,p)

            }
        }
    }

    fun estaEnArea(event: MotionEvent):Boolean{

        if(event.x >= x && event.x<=x+ancho){
            if(event.y >= y && event.y<=y+alto){
                return true
            }
        }
        return false
    }


}