package com.example.ladm_u2_p3_david_alejandro_hernandez_rubio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    var lienzo : Lienzo ?= null
    var hiloP1 : Hilo ?= null
    var hiloP2 : Hilo ?= null
    var hiloP3 : Hilo ?= null
    var hiloP4 : Hilo ?= null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lienzo = Lienzo(this)
        setContentView(lienzo)
        hiloP1 = Hilo(this)
        hiloP2 = Hilo(this)
        hiloP3 = Hilo(this)
        hiloP4 = Hilo(this)
        hiloP1!!.start()
        hiloP2!!.start()
        hiloP3!!.start()
        hiloP4!!.start()

    }
}
